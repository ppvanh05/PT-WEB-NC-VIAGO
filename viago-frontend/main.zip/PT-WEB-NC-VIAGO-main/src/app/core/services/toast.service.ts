import { Service } from '@angular/core';

@Service()
export class ToastService {}
